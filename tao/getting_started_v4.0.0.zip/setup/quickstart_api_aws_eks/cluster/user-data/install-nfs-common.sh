apt-get -y update
apt-get -y install nfs-common